var attachFastClick = require('fastclick');
attachFastClick(document.body);