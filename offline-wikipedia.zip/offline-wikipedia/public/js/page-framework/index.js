require('angular');
require('../page');